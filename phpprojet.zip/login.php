<html>
<head>
	<title>Page de connexion</title>
</head>
<body>
	<table border="0">
		<form action="loginverif.php" method="post">
		<tr>
			<td>Pseudo : </td><td><input type="text" name="pseudo" placeholder="Votre pseudo"></td>
		</tr>
		<tr>
			<td>Mot de passe : </td><td><input name="motdepasse" type="password" placeholder="********"></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="valider" value="Connexion"></td>
		</form>
	</table>




</body>
</html>
