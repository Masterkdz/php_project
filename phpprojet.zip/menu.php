<nav>
	<ul>
		<a href='index.php'><li><img src="img/testcaret.png">Accueil</li></a>
		<a href='#'><li><img src="img/testcaret.png">Nouveaut&eacute;s</li></a>
		<a href='#'><li><img src="img/testcaret.png">Bestiaire</li></a>
		<a href='#'><li><img src="img/testcaret.png">Boutique</li></a>
		<a href='#'><li><img src="img/testcaret.png">Extras</li></a>
		<a href='livreor.htm'><li><img src="img/testcaret.png">Livre d'or</li></a>
		<a href='#'><li><img src="img/testcaret.png">Contact</li></a>
		<a href='pageinscription.php'><li><img src="img/testcaret.png">Inscrivez-vous</li></a>
</nav>