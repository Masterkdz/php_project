<?php
$a="yak";

$a=hash("whirlpool","$a");
echo $a;
?>