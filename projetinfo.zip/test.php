<html>
<head>
	<title>test</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<h1>La Wii U, nouvelle console de salon</h1>
	<p><hr class='par'>	C'est a l'E3 2011 que la nouvelle de Nintendo a &eacute;t&eacute; annonc&eacute;e. Elle fait partie de la huiti&egrave;me g&eacute;n&eacute;ration
	 de consoles et propose in gameplay in&eacute;dit.
		En effet, la Wii U est la premi&egrave;re console de salon &agrave; proposer une manette avec un &eacute;cran tactile int&eacute;gr&eacute;,
		 le Wii U GamePad,bien que ce concept provienne de la GameCube,pouvant &ecirc;tre connect&eacute;e &agrave; la Game Boy Advance via un c&acirc;ble. Les deux principales nouveaut&eacute;s de la console sont apport&eacute;es par celui-ci. D'une part, le Wii U GamePad permet, mais seulement pour certains jeux, de continuer une partie, gr&acirc;ce &agrave; son &eacute;cran int&eacute;gr&eacute;, m&ecirc;me lorsque la t&eacute;l&eacute;vision n'est pas disponible. D'autre part en compl&eacute;ment 'logique' de la pr&eacute;c&eacute;dente, il offre en multijoueur une exp&eacute;rience de jeu dite "d'informations asym&eacute;triques" des participants, c'est-&agrave;-dire que les joueurs ne disposent pas forcement des m&ecirc;mes informations sur l'affichage de leur pad respectif.
		A sa sortie, une gamme vari&eacute;e de jeu utilisant le gamepad  apparaissent.
		 On peut citer les plus connus tels que : New super Mario Bros U , ou envore Zombie U (un jeu survival horror)
		 . L'avis des joueurs est tr&egrave;s partag&eacute; quant &agrave; cette console : certains la disent 'r&eacute;volutionnaire' , et d'autres restent &agrave; l'&eacute;cart car pour eux la Wii U reste tr&eacute;s proche de l'ancienne version. </p>
</head>
<body>

</body>
</html>