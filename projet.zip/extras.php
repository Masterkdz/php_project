<title>Extras</title>
<?php
require_once("connect_login.php");
include("entete.php");
include("menu.php");
echo "<h1>Vous trouverez ici divers extras que nous vous offrons!</h1><p><a href='classgenerator.php'>
	Cliquez ici pour acc&eacute;der au premier ClassGenerator du jeu : Call of Duty 4 - Modern Warfare!</a></p>";
?>