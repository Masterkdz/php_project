<!doctype html>
<html>
<head><title>Accueil</title></head>
<?php
include("entete.php");
include("menu.php");
echo "<h1>Acceuil !</h1>";
?>
<p style="font-family:Commons; font-size:60px ;text-align:center ; color : white">


Bienvenue sur notre site, nous esp�rons que vous trouverez tout ce qui vous interesse




</p>
</body>
</html>