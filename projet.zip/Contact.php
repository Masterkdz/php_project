<html>
<head><title>Nous contacter</title></head>
<?php
include("entete.php");
include("menu.php");


echo "<body>
<p style='font-family:Commons; font-size:60; text-align:center ; color : white'>    Contactez nous     </p>





<p style='font-family:Commons; font-size:20; text-align:center ; color : white ; text-align:right'> De Zorzi Kevin   </p>
<p style='font-family:Commons; font-size:20; text-align:center ; color : white ;text-align:right'> 06 09 69 08 71 </p>
<p style='font-family:Commons; font-size:20; text-align:center ; color : white ;text-align:right'> kevin.dezorzi@hotmail.fr </p>


<p style='font-family:Commons; font-size:20; text-align:center ; color : white ;text-align:left'> Doncourt Vincent </p>
<p style='font-family:Commons; font-size:20; text-align:center ; color : white ;text-align:left'> 06 81 94 33 42 </p>
<p style='font-family:Commons; font-size:20; text-align:center ; color : white ;text-align:left'> Vync@hotmail.fr </p>";
?>



</html>



